#ifndef PRINT_H_
#define PRINT_H_

#include "util.h"

/*
 * function @printStatus print all information
 * TODO
 */

int printStatus(int cycles);

// print a ROB pointer
void printPointROB(struct ROB_line *this_ROB);

#endif
